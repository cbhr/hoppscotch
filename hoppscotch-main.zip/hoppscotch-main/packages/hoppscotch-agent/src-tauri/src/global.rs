pub const AGENT_STORE: &str = "app_data.bin";
pub const REGISTRATIONS: &str = "registrations";
pub const NONCE: &str = "X-Hopp-Nonce";
