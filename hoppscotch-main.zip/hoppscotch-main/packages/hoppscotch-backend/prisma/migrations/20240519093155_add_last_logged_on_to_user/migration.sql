-- AlterTable
ALTER TABLE "User" ADD COLUMN     "lastLoggedOn" TIMESTAMP(3);
