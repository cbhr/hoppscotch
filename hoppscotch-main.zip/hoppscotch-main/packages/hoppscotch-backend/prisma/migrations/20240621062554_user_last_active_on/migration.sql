-- AlterTable
ALTER TABLE "User" ADD COLUMN     "lastActiveOn" TIMESTAMP(3);
