-- AlterTable
ALTER TABLE "InfraConfig" ADD COLUMN     "isEncrypted" BOOLEAN NOT NULL DEFAULT false;
