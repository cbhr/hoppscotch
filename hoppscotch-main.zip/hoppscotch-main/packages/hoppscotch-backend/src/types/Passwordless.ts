export type DeviceIdentifierToken = {
  deviceIdentifier: string;
};
