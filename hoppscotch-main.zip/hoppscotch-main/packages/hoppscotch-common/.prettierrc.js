module.exports = {
  semi: false,
  trailingComma: "es5",
  singleQuote: false,
  printWidth: 80,
  useTabs: false,
  tabWidth: 2,
}
