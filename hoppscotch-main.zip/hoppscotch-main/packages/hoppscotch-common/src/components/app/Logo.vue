<template>
  <svg
    width="824"
    height="824"
    viewBox="0 0 824 824"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="824" height="824" rx="184" fill="#08110F" />
    <rect
      width="824"
      height="824"
      rx="184"
      fill="url(#paint0_radial_0_21)"
      fill-opacity="0.5"
    />
    <path
      d="M435.425 463.217C429.441 476.657 411.033 481.515 394.309 474.07C377.585 466.624 368.879 449.693 374.863 436.253C380.846 422.813 399.254 417.954 415.978 425.4C432.702 432.846 441.409 449.777 435.425 463.217Z"
      fill="url(#paint1_linear_0_21)"
    />
    <path
      d="M435.425 463.217C429.441 476.657 411.033 481.515 394.309 474.07C377.585 466.624 368.879 449.693 374.863 436.253C380.846 422.813 399.254 417.954 415.978 425.4C432.702 432.846 441.409 449.777 435.425 463.217Z"
      fill="url(#paint2_radial_0_21)"
      style="mix-blend-mode: soft-light"
    />
    <path
      d="M535.563 521.172C553.071 526.191 570.536 518.856 574.571 504.789C578.606 490.722 567.684 475.251 550.175 470.232C532.666 465.213 515.201 472.548 511.166 486.615C507.131 500.682 518.054 516.153 535.563 521.172Z"
      fill="url(#paint3_linear_0_21)"
    />
    <path
      d="M535.563 521.172C553.071 526.191 570.536 518.856 574.571 504.789C578.606 490.722 567.684 475.251 550.175 470.232C532.666 465.213 515.201 472.548 511.166 486.615C507.131 500.682 518.054 516.153 535.563 521.172Z"
      fill="url(#paint4_radial_0_21)"
      style="mix-blend-mode: soft-light"
    />
    <path
      d="M292.782 355.633C308.227 365.286 314.462 383.173 306.709 395.584C298.955 407.995 280.149 410.231 264.704 400.578C249.258 390.924 243.023 373.037 250.777 360.626C258.53 348.215 277.337 345.98 292.782 355.633Z"
      fill="url(#paint5_linear_0_21)"
    />
    <path
      d="M292.782 355.633C308.227 365.286 314.462 383.173 306.709 395.584C298.955 407.995 280.149 410.231 264.704 400.578C249.258 390.924 243.023 373.037 250.777 360.626C258.53 348.215 277.337 345.98 292.782 355.633Z"
      fill="url(#paint6_radial_0_21)"
      style="mix-blend-mode: soft-light"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M502.355 231.325C581.373 266.506 632.095 343.263 634.119 429.03C680.633 465.639 726.858 516.883 705.36 565.168C681.25 619.319 595.382 617.091 497.781 589.689C450.767 615.718 392.444 620.168 339.689 596.68C286.934 573.192 251.229 526.908 239.1 474.517C153.428 420.321 94.3151 357.999 118.425 303.847C139.923 255.562 208.935 255.626 267.265 265.697C332.356 209.81 423.338 196.144 502.355 231.325ZM159.38 322.082C147.667 348.389 210.578 423.052 382.845 499.751C555.111 576.449 652.693 573.241 664.405 546.934C674.099 525.16 634.213 483.308 588.537 450.878C553.009 425.484 504.344 397.494 440.864 369.231C423.586 361.538 416.839 341.008 424.104 324.691C431.369 308.374 447.329 297.463 480.93 295.91C496.747 295.862 498.823 291.476 499.546 287.716C500.442 281.915 492.401 276.002 484.108 272.31C418.17 242.953 337.453 255.265 281.503 314.178C226.84 301.933 169.074 300.309 159.38 322.082Z"
      fill="url(#paint7_linear_0_21)"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M502.355 231.325C581.373 266.506 632.095 343.263 634.119 429.03C680.633 465.639 726.858 516.883 705.36 565.168C681.25 619.319 595.382 617.091 497.781 589.689C450.767 615.718 392.444 620.168 339.689 596.68C286.934 573.192 251.229 526.908 239.1 474.517C153.428 420.321 94.3151 357.999 118.425 303.847C139.923 255.562 208.935 255.626 267.265 265.697C332.356 209.81 423.338 196.144 502.355 231.325ZM159.38 322.082C147.667 348.389 210.578 423.052 382.845 499.751C555.111 576.449 652.693 573.241 664.405 546.934C674.099 525.16 634.213 483.308 588.537 450.878C553.009 425.484 504.344 397.494 440.864 369.231C423.586 361.538 416.839 341.008 424.104 324.691C431.369 308.374 447.329 297.463 480.93 295.91C496.747 295.862 498.823 291.476 499.546 287.716C500.442 281.915 492.401 276.002 484.108 272.31C418.17 242.953 337.453 255.265 281.503 314.178C226.84 301.933 169.074 300.309 159.38 322.082Z"
      fill="url(#paint8_radial_0_21)"
      style="mix-blend-mode: soft-light"
    />
    <defs>
      <radialGradient
        id="paint0_radial_0_21"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(814.524 12.36) rotate(125.613) scale(1089.59 1210.34)"
      >
        <stop stop-color="#00D196" stop-opacity="0.5" />
        <stop offset="0.996771" stop-color="#00D196" stop-opacity="0" />
      </radialGradient>
      <linearGradient
        id="paint1_linear_0_21"
        x1="411.893"
        y1="212"
        x2="411.893"
        y2="612"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#00D196" />
        <stop offset="1" stop-color="#00B381" />
      </linearGradient>
      <radialGradient
        id="paint2_radial_0_21"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(644.721 344.481) rotate(159.984) scale(631.37 385.135)"
      >
        <stop stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </radialGradient>
      <linearGradient
        id="paint3_linear_0_21"
        x1="411.893"
        y1="212"
        x2="411.893"
        y2="612"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#00D196" />
        <stop offset="1" stop-color="#00B381" />
      </linearGradient>
      <radialGradient
        id="paint4_radial_0_21"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(644.721 344.481) rotate(159.984) scale(631.37 385.135)"
      >
        <stop stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </radialGradient>
      <linearGradient
        id="paint5_linear_0_21"
        x1="411.893"
        y1="212"
        x2="411.893"
        y2="612"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#00D196" />
        <stop offset="1" stop-color="#00B381" />
      </linearGradient>
      <radialGradient
        id="paint6_radial_0_21"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(644.721 344.481) rotate(159.984) scale(631.37 385.135)"
      >
        <stop stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </radialGradient>
      <linearGradient
        id="paint7_linear_0_21"
        x1="411.893"
        y1="212"
        x2="411.893"
        y2="612"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#00D196" />
        <stop offset="1" stop-color="#00B381" />
      </linearGradient>
      <radialGradient
        id="paint8_radial_0_21"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(644.721 344.481) rotate(159.984) scale(631.37 385.135)"
      >
        <stop stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </radialGradient>
    </defs>
  </svg>
</template>
