<template>
  <IconLucideCheckCircle class="text-accent" />
</template>
